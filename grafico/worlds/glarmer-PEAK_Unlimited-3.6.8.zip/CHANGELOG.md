### 3.6.7 / 8

* Fixes empty screen for non host players in certain instances - Thank you to [**@dellamorteJ**](https://github.com/dellamorteJ) for this fix!
* .8 is just to append the changelog as I forgot to upload the new one :)

### 3.6.6

* Fixes minor error when placing a portable stove

### 3.6.5

* Brought hotdog spawn rate down to the same as vanilla
* Changed options to read "Campfire Food" instead of "Marshmallows"
* Added an option for hotdog spawn rate which by default is set to the vanilla value

### 3.6.4

* Update BepInEx Dependency

### 3.6.3

* Stop duplicate marshmallow spawning
* Glizzies spawn as well as marshmallows

### 3.6.0/1/2

* Roots compat

### 3.5.0

* Made the mod compatible with ModConfig, now if you have the two mods installed you will see the PEAK Unlimited settings in the ModConfig settings. Note: the old mod menu is still available, and PEAK Unlimited can run without ModConfig. Thanks to [**darmuh**](https://github.com/darmuh/) for helping with this

#### The credit for the following changes go to [**senft-research**](https://github.com/senft-research) - Thank you for the valuable contributions!

* Implemented a hugely improved and configurable logging system for debug purposes
* Found and fixed a bug which resulted in late joiners not being able to progress past Caldera under certain circumstances.

### 3.4.3

* Fixes an error when someone joins or leaves after a whole game has been played and the party returns to the airport.

### 3.4.2

* Another hotfix. Fixes an error when someone joins the airport.

### 3.4.1

* Just a quick fix to stop marshmallows at the previous campfire being despawned when someone leaves/rejoins.

### 3.4.0

A variety of upgrades to the way marshmallows spawn have been made:

* PEAK Unlimited replaces the vanilla marshmallows, making the behaviour and layout of campfire marshmallows more consistent
* Marshmallows should now almost always spawn wedged in the floor. Floating marshmallows should be rare. Marshmallows should never spawn entirely underground.
* Late join marshmallows work and are enabled by default. The option is also added to the menu and join log info.
* The cheatmallows setting no longer requires the extra marshmallows setting to be set to True/On - if its set to a non-zero value it will spawn that exact number of marshmallows.
* Marshmallows will spawn broadly facing the campfire, but I have added some randomness to their rotation as perfect alignment looked almost cult-like

### 3.3.0

* Menu keybind can now be changed from F2 to any key. You can do this via the menu itself or via the configuration file.
* The menu can be scaled with +/-. More accessibility options to come.

### 3.2.0

* Max players can now be changed without a restart (only while in the main menu).
* Options are now disabled in the mod UI when they can't take effect - e.g. Max Players will be greyed out once you start a game.
* Experimental audio patch to help prevent VoIP issues

### 3.1.1

* README edit

### 3.1.0

* Add an in game UI for configuring the mod (Open by pressing F2, can still configure in the configuration file as normal if preferred)
* Fix marshmallow and backpack spawns in the Mesa and Caldera

### 3.0.0

* Add the ability to lock the kiosk to host only (so the host can only start)
* Displays lobby details when you load in (Can be disabled in the configuration)
* Fixed a bug where disabling extra marshmallows would also disable extra backpacks
* Refactored the mod

### 2.8.0

* Extra logging for easier debugging
* Backpacks should be working on Mesa Update

### 2.7.3

* Mesa Update changes to readme

### 2.7.2

* Backpack spawning

### 2.7.1

* README Edit

### 2.5.0 - 2.7.0

* Fixed the end screen
* Made it so the host can press "Next" on the end screen and skip it for all players (means that other players don't need the mod installed, however, if they do install it they should see a fixed end screen also)

### 2.4.0

* Fixed 2 marshmallows in alpine always spawning underground
* Fixed caldera marshmallows floating just above the ground
* Fixed cheat marshmallows spawning an extra marshmallow if there are less than 4 players

### 2.3.2

* README changes as wording was confusing some people

### 2.3.1

* Add a host check and change get ground method

### 2.3.0

* Change the method of setting max player count so that its more compatible with things like the new lobby privacy settings

### 2.2.3

* Removes a test spawn marshmallow Keybind I mistakenly forgot to remove from the prior release.
* Add link to PeakUnlimitedEndScreen mod by kaosz in readme

### 2.2.2

* Rewrite the marshmallow code to be more reliable.
* Restore config option to set a desired amount of marshmallows.

### 2.2.1

* Revert 2.2.0, back to 2.1.1 (2.2.0 broke extra marshmallows, will fix 2.2.0 in 2.2.2)

### 2.2.0

* Removes some debug stuff
* Adds a configuration setting to cheat in even more marshmallows!

### 2.1.1

* Accidentally left debug +20 marshmallows in 2.1.0, this fixes that. Now the correct amount of marshmallows will spawn. Sorry, I pulled an all nighter testing the marshmallow stuff!

### 2.1.0

* Added rotation to marshmallows for nicer visual effect
* Added a changelog

### 2.0.0 (Marshmallows!)

* Added configurable extra marshmallows for the additional players

### 1.3.0

* Edited the max player cap to lessen strain on servers

### 1.0.0 - 1.2.7

* Various README improvements
* Images
* Icon updates
* BepInEx version change
* A couple minor code changes
